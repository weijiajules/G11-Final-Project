import hsa.*;

//change name of class here
public class TestMarker {

    public static Console c;
    
    public static void main(String args[])
    {
        c = new Console();
        c.println("Hello world");
        
    }
    
}
