
import processing.core.*;
import g4p_controls.*;
import javax.swing.JOptionPane;

//change name of class:
public class BowlingScoreApp extends PApplet {

    GButton btnscore[][] = new GButton[4][10];
    int score[][] = new int[4][10];
    int frameon = 1;

    GLabel lblnames[] = new GLabel[4];
    GLabel lblscores[] = new GLabel[4];

    String names[] = {"Chrome", "Don", "Koro Sensi", "NET BEANS"};
    int totals[] = {0, 0, 0, 0};
    int pcounter=0, fcounter=0;// counts plavers turns and  frames
    

    public void setup() {
        size(800, 480, JAVA2D);

        // make 40 buttons
        int xloc = 150, yloc = 50;
        for (int pl = 0; pl < 4; pl++) {
            
            // puts names at stat if fram buttons
            lblnames[pl] = new GLabel(this, 80, yloc, 50, 40);
            lblnames[pl].setText(names[pl]);
            
            // put score at end of fram buttons
            lblscores[pl] = new GLabel(this, 650, yloc, 50, 40);
            lblscores[pl].setText("" + totals[pl]);

            for (int fr = 0; fr < 10; fr++) {
                btnscore[pl][fr] = new GButton(this, xloc, yloc, 40, 40);
                btnscore[pl][fr].setText("frame " + frameon);
                btnscore[pl][fr].setEnabled(false);
                xloc += 50;
                frameon++;

            }// go to next frame for this paleyre
            // go to next player
            xloc = 150;// goign back to left next player
            yloc += 100; // moving diqn ot next payer
            frameon = 1;

        }
        //turns om frist button
        btnscore[0][0].setEnabled(true);
        btnscore[0][0].setLocalColorScheme(0); // red
        frameon=1;

    }

    public void handleButtonEvents(GButton button, GEvent event) {

        //code for buttons goes here
        
        // diables button tatwas clickes
        btnscore[pcounter][fcounter].setEnabled(false);
        //reset its colour
          btnscore[pcounter][fcounter].setLocalColorScheme(6);
          
          // recored score fo rhtat bowelre
          score[pcounter][fcounter]= Integer.parseInt(
                  JOptionPane.showInputDialog(this, " enter score for " + names[pcounter] + "| Frame: " + frameon));
          // put schore on button
           btnscore[pcounter][fcounter].setText(""+score[pcounter][fcounter]);
           // add score to plyer toatal, update dispay
           totals[pcounter]+= score[pcounter][fcounter];
           lblscores[pcounter].setText("" + totals[pcounter]);
          
          // next button
          pcounter++;
          if(pcounter==4){
              pcounter=0; // go back to paklwer 1
              fcounter++;// go to next feamw
              frameon++; // thsi is always 1 more than 
          }
          // turn nes bootn on and set to red
          btnscore[pcounter][fcounter].setEnabled(true);
           btnscore[pcounter][fcounter].setLocalColorScheme(0);
    }

    public void draw() {
        background(240, 240, 220); //light tan

    }

    //this is needed to run the program
    public static void main(String ags[]) {
        PApplet.main(new String[]{BowlingScoreApp.class.getName()});
    }

}
