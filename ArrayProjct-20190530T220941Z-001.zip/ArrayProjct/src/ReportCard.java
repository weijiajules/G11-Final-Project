
import hsa.*;
import java.io.File;
import java.util.Scanner;

//change name of class here
public class ReportCard {

    public static Console c;
    static String students[] = new String[20];
    static int marks[][] = new int[20][4];
    static String choice = new String();

    public static void main(String args[]) {

        c = new Console();
        File f = new File("studentmarks.txt");
        try {

            Scanner s = new Scanner(f);

            for (int x = 0; x < 20; x++) {
                students[x] = s.next() + " " + s.next();

                for (int y = 0; y < 4; y++) {
                    marks[x][y] = s.nextInt();

                }

            }
            s.close();

        } catch (Exception ex) {
            c.println(ex.toString());
        }

        while (true) {
            drawMenu();
            choice = c.readLine();
            if (choice.equals("quit")) {
                break;
            }
            int loc = search(choice);
            if (loc == -1) {
                c.println(choice + " was not found in the student list.");
            } else {
reportCard(loc);
pause();

            }
//c.close();
        }

    }

    public static void drawMenu() {
        for (int i = 0; i < 20; i++) {
            c.println(students[i]);
        }
        c.print("enter a name or enter 'quit' to exit >");
    }

    public static int search(String p) {
        // p is prodoct im lloking ofor
        for (int i = 0; i < students.length; i++) {
            if (p.equals(students[i])) {
                // we matched reatun location where that happend
                return i;

            }
        }
        return -1;
    }
    public static void reportCard(int loc){
        c.clear();
        c.println("REPORT CARD FOR "+ students[loc]);
        c.println("====================================\n");
        double avg=0;
        
        for (int y = 0; y < 4; y++) {
            c.print("Period "+ (y+1),15);
            c.println(marks[loc][y]);
            avg += marks[loc][y];
            
        }
        avg=avg/4;
        c.println("---------------------------------");
        c.print("average: ",15);
        c.println(avg);
        
    }
    static void pause(){
        
        c.println("\n\n Press any key to contune");
        c.getChar();
        c.clear();
        
    }
}
