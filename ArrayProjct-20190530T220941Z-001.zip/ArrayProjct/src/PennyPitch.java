
import processing.core.*;
import g4p_controls.*;

//change name of class:
public class PennyPitch extends PApplet {
    prizebox x, y;
    prizebox z[]= new prizebox[5];

    public void setup() {
        size(640, 480, JAVA2D);
        x=new prizebox (200,200);
        y=new prizebox(300,200);
        
        
for (int i = 0; i < 5; i++) {
            z[i]=new prizebox(i*100+50,100);  
        }

        x.setPrize("CAT");
        y.tossPenny();
        y.tossPenny();
        
        z[4].setPrize("DOG");
        z[0].tossPenny();
        
        
       
        
        System.out.println("does x have a penny "+x.hasPenny());
        System.out.println("does y have a penny "+y.hasPenny());
        
        
        if (x.hasPrize()){
            System.out.println("x has the prize "+x.getPrize());
        }
        else System.out.println("x has no prize ");
        
          if (y.hasPrize()){
            System.out.println("y has the prize "+y.getPrize());
        }
        else System.out.println("y has no prize ");
        
    }

    public void handleButtonEvents(GButton button, GEvent event) {

        //code for buttons goes here
    }

    public void draw() {
        background(240, 240, 220); //light tan
        x.drawbox(); // draws prize box with blck box amd wwhite border
        y.drawbox();
        for (int i = 0; i < 5; i++) {
            z[i].drawbox();
        }

    }

    //this is needed to run the program
    public static void main(String ags[]) {
        PApplet.main(new String[]{PennyPitch.class.getName()});
    }

    class prizebox {

        int xloc, yloc;

        String prize;

        String p;

        prizebox(int x, int y) {

            xloc = x;
            yloc = y;

            prize = "";

            p = "";

        }

        void setPrize(String p) {

            prize = p;

        }

        String getPrize() {

            return prize;

        }

        boolean hasPrize() {

            if (prize != "") {
                return true;
            } else {
                return false;
            }

        }

        void tossPenny() {

            p += "X";

        }

        boolean hasPenny() {

            if (p.length() > 0) {
                return true;
            } else {
                return false;
            }

        }

        void drawbox() {

            fill(0);

            stroke(255);

            strokeWeight(5);

            rect(xloc, yloc, 80, 80);

            fill(255);

            text(prize, xloc + 10, yloc + 30);

            fill(255, 0, 0);

            text(p, xloc + 10, yloc + 55);

        }

    }

}
